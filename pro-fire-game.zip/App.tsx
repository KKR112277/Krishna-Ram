
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import Home from './components/Home';
import Characters from './components/Characters';
import Weapons from './components/Weapons';
import GameModes from './components/GameModes';
import StrategyGenerator from './components/StrategyGenerator';

export type Page = 'Home' | 'Characters' | 'Weapons' | 'Game Modes' | 'Strategy AI';

const App: React.FC = () => {
    const [currentPage, setCurrentPage] = useState<Page>('Home');

    const renderPage = () => {
        switch (currentPage) {
            case 'Home':
                return <Home />;
            case 'Characters':
                return <Characters />;
            case 'Weapons':
                return <Weapons />;
            case 'Game Modes':
                return <GameModes />;
            case 'Strategy AI':
                return <StrategyGenerator />;
            default:
                return <Home />;
        }
    };

    const handleNavClick = useCallback((page: Page) => {
        setCurrentPage(page);
    }, []);

    return (
        <div className="min-h-screen bg-gray-900 text-gray-100 font-sans antialiased">
            <div 
                className="absolute top-0 left-0 w-full h-full bg-cover bg-center bg-no-repeat opacity-10"
                style={{backgroundImage: 'url(https://picsum.photos/seed/profire-bg/1920/1080)'}}
            ></div>
            <div className="relative z-10">
                <Header onNavClick={handleNavClick} currentPage={currentPage} />
                <main className="container mx-auto px-4 py-8">
                    {renderPage()}
                </main>
            </div>
        </div>
    );
};

export default App;
