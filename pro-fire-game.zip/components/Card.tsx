
import React from 'react';

interface CardProps {
    title: string;
    subtitle: string;
    description: string;
    imageUrl: string;
    subtitleColor?: string;
    aspectRatio?: string;
}

const Card: React.FC<CardProps> = ({ title, subtitle, description, imageUrl, subtitleColor = 'text-orange-400', aspectRatio = 'aspect-w-3 aspect-h-4' }) => {
    return (
        <div className="bg-gray-800/50 border border-gray-700 rounded-lg overflow-hidden group transition-all duration-300 hover:border-orange-500 hover:scale-105 hover:shadow-2xl hover:shadow-orange-500/20">
            <div className={`w-full overflow-hidden ${aspectRatio}`}>
                <img src={imageUrl} alt={title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
            </div>
            <div className="p-4">
                <h3 className="text-xl font-bold uppercase tracking-wide">{title}</h3>
                <p className={`text-sm font-semibold uppercase ${subtitleColor} mb-2`}>{subtitle}</p>
                <p className="text-gray-400 text-sm">{description}</p>
            </div>
        </div>
    );
};

export default Card;
