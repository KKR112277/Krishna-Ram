
import React from 'react';
import { CHARACTERS } from '../constants';
import Card from './Card';

const Characters: React.FC = () => {
    return (
        <div>
            <h2 className="text-4xl font-bold text-center mb-2 uppercase tracking-wider">Meet the Legends</h2>
            <p className="text-center text-gray-400 mb-10">Each character has a unique ability to turn the tide of battle.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
                {CHARACTERS.map((character) => (
                    <Card key={character.name}
                        title={character.name}
                        subtitle={character.ability}
                        description={character.description}
                        imageUrl={character.imageUrl}
                        subtitleColor="text-cyan-400"
                    />
                ))}
            </div>
        </div>
    );
};

export default Characters;
