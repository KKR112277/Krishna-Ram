
import React from 'react';
import type { GameMode } from '../types';
import { UserIcon, UsersIcon, UserGroupIcon } from './Icons';

const gameModesData: GameMode[] = [
    {
        name: 'Solo',
        description: 'It\'s you against everyone else. The ultimate test of skill and survival. Only one can be the victor.',
        icon: <UserIcon className="w-16 h-16 text-orange-500 mb-4" />,
    },
    {
        name: 'Duo',
        description: 'Team up with a friend. Communication and coordination are key to outplaying other pairs on the island.',
        icon: <UsersIcon className="w-16 h-16 text-orange-500 mb-4" />,
    },
    {
        name: 'Squad',
        description: 'Form a 4-player team and fight for supremacy. Revive your teammates and execute strategies to win together.',
        icon: <UserGroupIcon className="w-16 h-16 text-orange-500 mb-4" />,
    },
];

const GameModes: React.FC = () => {
    return (
        <div>
            <h2 className="text-4xl font-bold text-center mb-2 uppercase tracking-wider">Choose Your Battle</h2>
            <p className="text-center text-gray-400 mb-12">Play alone or team up with friends. How will you conquer the island?</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
                {gameModesData.map((mode) => (
                    <div key={mode.name} className="bg-gray-800/50 p-8 rounded-lg border border-gray-700 text-center flex flex-col items-center hover:border-orange-500 transition-colors duration-300 hover:bg-gray-800">
                        {mode.icon}
                        <h3 className="text-2xl font-bold mb-2 uppercase">{mode.name}</h3>
                        <p className="text-gray-400">{mode.description}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default GameModes;
