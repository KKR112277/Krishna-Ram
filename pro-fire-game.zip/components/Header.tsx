
import React from 'react';
import type { Page } from '../App';
import { FireIcon } from './Icons';

interface HeaderProps {
    onNavClick: (page: Page) => void;
    currentPage: Page;
}

const Header: React.FC<HeaderProps> = ({ onNavClick, currentPage }) => {
    const navItems: Page[] = ['Home', 'Characters', 'Weapons', 'Game Modes', 'Strategy AI'];

    return (
        <header className="bg-black/30 backdrop-blur-sm sticky top-0 z-50 shadow-lg shadow-orange-500/10">
            <div className="container mx-auto px-4">
                <div className="flex justify-between items-center py-4">
                    <div className="flex items-center space-x-2 cursor-pointer" onClick={() => onNavClick('Home')}>
                        <FireIcon className="w-8 h-8 text-orange-500" />
                        <h1 className="text-2xl font-bold tracking-wider uppercase text-shadow">
                            Pro-Fire<span className="text-orange-500">.</span>GG
                        </h1>
                    </div>
                    <nav className="hidden md:flex items-center space-x-6">
                        {navItems.map((item) => (
                            <button
                                key={item}
                                onClick={() => onNavClick(item)}
                                className={`uppercase font-semibold text-sm tracking-widest transition-colors duration-300 relative py-1
                                    ${currentPage === item ? 'text-orange-500' : 'text-gray-300 hover:text-white'}
                                `}
                            >
                                {item}
                                {currentPage === item && (
                                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-orange-500"></span>
                                )}
                            </button>
                        ))}
                    </nav>
                     <div className="md:hidden">
                        {/* Mobile menu button can be added here */}
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
