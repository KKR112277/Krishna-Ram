
import React from 'react';

const Home: React.FC = () => {
    return (
        <div className="text-center py-16 md:py-32">
            <h1 className="text-5xl md:text-7xl font-extrabold uppercase tracking-widest text-white mb-4"
                style={{ textShadow: '0 0 10px rgba(249, 115, 22, 0.7), 0 0 20px rgba(249, 115, 22, 0.5)' }}>
                Welcome to Pro-Fire
            </h1>
            <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto mb-8">
                Your ultimate companion for the fast-paced, competitive battle-royale experience. Explore characters, master weapons, and get AI-powered strategies to dominate the island.
            </p>
            <div className="flex justify-center space-x-4">
                <button className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-8 rounded-sm uppercase tracking-wider transition-transform transform hover:scale-105">
                    Get Started
                </button>
                <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-8 rounded-sm uppercase tracking-wider transition-transform transform hover:scale-105">
                    Watch Trailer
                </button>
            </div>
        </div>
    );
};

export default Home;
