
import React, { useState, useCallback } from 'react';
import { CHARACTERS, PLAY_STYLES } from '../constants';
import { generateStrategy } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import { BrainCircuitIcon } from './Icons';

const StrategyGenerator: React.FC = () => {
    const [character, setCharacter] = useState(CHARACTERS[0].name);
    const [gameMode, setGameMode] = useState('Squad');
    const [playStyle, setPlayStyle] = useState(PLAY_STYLES[0]);
    const [strategy, setStrategy] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleGenerate = useCallback(async () => {
        setIsLoading(true);
        setError('');
        setStrategy('');
        const selectedCharacter = CHARACTERS.find(c => c.name === character);
        if (!selectedCharacter) {
            setError('Please select a valid character.');
            setIsLoading(false);
            return;
        }
        try {
            const result = await generateStrategy(character, selectedCharacter.ability, gameMode, playStyle);
            setStrategy(result);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    }, [character, gameMode, playStyle]);

    const formatStrategy = (text: string) => {
        return text
            .split('\n')
            .map((line, index) => {
                if (line.startsWith('**') && line.endsWith('**')) {
                    return <h4 key={index} className="text-lg font-bold text-orange-400 mt-4 mb-2">{line.replace(/\*\*/g, '')}</h4>;
                }
                if (line.startsWith('* ')) {
                     return <li key={index} className="ml-5 list-disc">{line.substring(2)}</li>;
                }
                if (line.match(/^\d+\./)) {
                    return <h3 key={index} className="text-xl font-semibold text-cyan-400 mt-6 mb-2">{line}</h3>
                }
                return <p key={index} className="mb-2">{line}</p>;
            });
    };

    return (
        <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
                <BrainCircuitIcon className="w-16 h-16 mx-auto mb-4 text-orange-500" />
                <h2 className="text-4xl font-bold uppercase tracking-wider">AI Strategy Coach</h2>
                <p className="text-gray-400 mt-2">Get a personalized game plan from our advanced AI to secure your next victory.</p>
            </div>

            <div className="bg-gray-800/50 p-6 rounded-lg border border-gray-700 grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <div className="md:col-span-1">
                    <label htmlFor="character" className="block text-sm font-medium text-gray-300 mb-1">Character</label>
                    <select id="character" value={character} onChange={e => setCharacter(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 focus:ring-orange-500 focus:border-orange-500">
                        {CHARACTERS.map(c => <option key={c.name}>{c.name}</option>)}
                    </select>
                </div>
                <div className="md:col-span-1">
                    <label htmlFor="gameMode" className="block text-sm font-medium text-gray-300 mb-1">Game Mode</label>
                    <select id="gameMode" value={gameMode} onChange={e => setGameMode(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 focus:ring-orange-500 focus:border-orange-500">
                        <option>Solo</option>
                        <option>Duo</option>
                        <option>Squad</option>
                    </select>
                </div>
                <div className="md:col-span-1">
                    <label htmlFor="playStyle" className="block text-sm font-medium text-gray-300 mb-1">Playstyle</label>
                    <select id="playStyle" value={playStyle} onChange={e => setPlayStyle(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded-md py-2 px-3 focus:ring-orange-500 focus:border-orange-500">
                        {PLAY_STYLES.map(style => <option key={style}>{style}</option>)}
                    </select>
                </div>
                <button onClick={handleGenerate} disabled={isLoading} className="md:col-span-1 w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded-md uppercase tracking-wider transition-all transform hover:scale-105 disabled:bg-gray-500 disabled:cursor-not-allowed flex justify-center items-center">
                    {isLoading ? <LoadingSpinner /> : 'Generate'}
                </button>
            </div>

            <div className="mt-8">
                {error && <div className="bg-red-900/50 border border-red-700 text-red-300 p-4 rounded-md">{error}</div>}
                {strategy && (
                    <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700 prose prose-invert max-w-none text-gray-300">
                        <h3 className="text-2xl font-bold text-white mb-4">Your Custom Strategy:</h3>
                        <div>{formatStrategy(strategy)}</div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default StrategyGenerator;
