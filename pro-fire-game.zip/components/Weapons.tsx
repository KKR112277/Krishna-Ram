
import React from 'react';
import { WEAPONS } from '../constants';
import Card from './Card';

const Weapons: React.FC = () => {
    return (
        <div>
            <h2 className="text-4xl font-bold text-center mb-2 uppercase tracking-wider">Know Your Arsenal</h2>
            <p className="text-center text-gray-400 mb-10">Master every tool of destruction to gain an edge.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
                {WEAPONS.map((weapon) => (
                    <Card key={weapon.name}
                        title={weapon.name}
                        subtitle={weapon.type}
                        description={weapon.description}
                        imageUrl={weapon.imageUrl}
                        subtitleColor="text-red-400"
                        aspectRatio="aspect-w-16 aspect-h-9"
                    />
                ))}
            </div>
        </div>
    );
};

export default Weapons;
