
import type { Character, Weapon } from './types';

export const CHARACTERS: Character[] = [
    {
        name: 'Blaze',
        ability: 'Faster Movement',
        description: 'Blaze can outrun opponents and reposition quickly with his enhanced speed, making him a hard target to hit.',
        imageUrl: 'https://picsum.photos/seed/blaze/400/500',
    },
    {
        name: 'Vanguard',
        ability: 'Stronger Defense',
        description: 'Vanguard\'s personal energy shield can absorb significant damage, allowing him to lead the charge into firefights.',
        imageUrl: 'https://picsum.photos/seed/vanguard/400/500',
    },
    {
        name: 'Doc',
        ability: 'Self-Healing',
        description: 'Doc can regenerate health over time, making her incredibly resilient in long battles without needing medkits.',
        imageUrl: 'https://picsum.photos/seed/doc/400/500',
    },
    {
        name: 'Hawkeye',
        ability: 'Extra Damage',
        description: 'Hawkeye deals increased damage with sniper rifles and marksman rifles, perfect for players who prefer long-range combat.',
        imageUrl: 'https://picsum.photos/seed/hawkeye/400/500',
    },
    {
        name: 'Ghost',
        ability: 'Stealth Camouflage',
        description: 'Ghost can become nearly invisible for a short period, allowing for surprise attacks and sneaky escapes.',
        imageUrl: 'https://picsum.photos/seed/ghost/400/500',
    },
];

export const WEAPONS: Weapon[] = [
    {
        name: 'Assault Rifle AR-15',
        type: 'Assault Rifle',
        description: 'A versatile rifle effective at medium to long range. Balanced damage, fire rate, and recoil.',
        imageUrl: 'https://picsum.photos/seed/ar15/400/300',
    },
    {
        name: 'SMG Vector',
        type: 'Submachine Gun',
        description: 'A high fire-rate SMG deadly in close-quarters combat. Low recoil but less effective at a distance.',
        imageUrl: 'https://picsum.photos/seed/vector/400/300',
    },
    {
        name: 'Sniper M24',
        type: 'Sniper Rifle',
        description: 'A powerful bolt-action sniper rifle capable of taking down enemies with a single headshot.',
        imageUrl: 'https://picsum.photos/seed/m24/400/300',
    },
    {
        name: 'Shotgun S12K',
        type: 'Shotgun',
        description: 'A semi-automatic shotgun that delivers devastating damage at close range. Great for clearing buildings.',
        imageUrl: 'https://picsum.photos/seed/s12k/400/300',
    },
    {
        name: 'Pistol G18',
        type: 'Pistol',
        description: 'A reliable sidearm with a high-capacity magazine, useful in early-game encounters.',
        imageUrl: 'https://picsum.photos/seed/g18/400/300',
    },
    {
        name: 'Grenade',
        type: 'Throwable',
        description: 'A standard fragmentation grenade that deals area-of-effect damage to flush out enemies from cover.',
        imageUrl: 'https://picsum.photos/seed/grenade/400/300',
    },
];

export const PLAY_STYLES = ['Aggressive', 'Defensive', 'Balanced', 'Stealth'];
