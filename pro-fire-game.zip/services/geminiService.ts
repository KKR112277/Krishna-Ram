
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might want to handle this more gracefully.
  // For this context, we assume the API key is always available.
  console.warn("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const generateStrategy = async (
    character: string,
    ability: string,
    gameMode: string,
    playStyle: string
): Promise<string> => {
    const prompt = `
        Act as an expert Pro-Fire e-sports coach. Pro-Fire is a fast-paced battle royale game similar to Free Fire.

        Generate a detailed, actionable game strategy for a player with the following setup:
        - Character: ${character}
        - Special Ability: ${ability}
        - Game Mode: ${gameMode}
        - Preferred Playstyle: ${playStyle}

        Your strategy should cover these key areas:
        1.  **Early Game (Landing & Looting):** Recommend a type of landing spot (hot drop vs. safe zone edge) and looting priorities that best suit the character's ability and playstyle.
        2.  **Mid Game (Rotation & Positioning):** How should the player move across the map? When should they engage in fights, and when should they avoid them? How can they best utilize their ability during this phase?
        3.  **Late Game (Final Circles):** What's the best approach for the final few safe zones? How should they leverage their character, gear, and playstyle to secure the win?
        4.  **Ability-Specific Tips:** Provide two unique, creative tips on how to maximize the effectiveness of the "${ability}" ability.

        Format the response clearly with headings for each section. Use bullet points for easy reading. The tone should be encouraging and strategic.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
        });

        if (response.text) {
            return response.text;
        } else {
            return "Could not generate a strategy. The model returned an empty response.";
        }
    } catch (error) {
        console.error("Error generating strategy:", error);
        return "An error occurred while generating your strategy. Please check your API key and try again.";
    }
};
