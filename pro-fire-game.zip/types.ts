// FIX: Import `ReactNode` from `react` to resolve 'Cannot find namespace React' error.
import type { ReactNode } from 'react';

export interface Character {
    name: string;
    ability: string;
    description: string;
    imageUrl: string;
}

export interface Weapon {
    name: string;
    type: string;
    description: string;
    imageUrl: string;
}

export interface GameMode {
    name: string;
    description: string;
    icon: ReactNode;
}
